﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmployeeTracker.BusinessLayer;
using EmployeeTracker.DTO;

namespace EmployeeTracker.Controllers
{
    public class EmployeeController : ApiController
    {
        public EmployeeService _employeeService;
        public EmployeeController()
        {
            _employeeService = new EmployeeService();
        }

        // GET api/order
        public HttpResponseMessage Get()
        {
            var emp = _employeeService.Get();
            if (emp != null)
                return Request.CreateResponse(HttpStatusCode.OK, emp);
            else return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No orders found");
        }

        // POST: api/Employees
        //public IHttpActionResult PostEmployee(EmployeeDto employee)
        //{
            ///var Emp = _employeeService.Get(employee.EmpId);
            //if (!ModelState.IsValid)
            //{
                //return BadRequest(ModelState);
            //}

            
           // db.Employees.Add(employee);

            //try
            //{

              //  await db.SaveChangesAsync();

            //}
            ////catch (DbUpdateException)
            ////{
            ////    if (EmployeeExists(employee.Id))
            ////    {
            ////        return Conflict();
            ////    }
            ////    else
            ////    {
            ////        throw;
            ////    }
            ////}

            //return CreatedAtRoute("DefaultApi", new { }, employee);
        //}

		
        //// PUT: api/Employees/5
        // we can perform edit employee method
        [ResponseType(typeof(void))]        
        public IHttpActionResult PutEmployee(int id, EmployeeDto empl)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != empl.EmpId)
            {
                return BadRequest();
            }
            // Calling the Reopsitory employee edit method
            _employeeService.edit(empl);

            return StatusCode(HttpStatusCode.NoContent);
        }

        //// POST: api/Employees/
        // we can perform add employee method
        [ResponseType(typeof(EmployeeDto))]
        public IHttpActionResult PostEmployee(EmployeeDto empl)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            // Calling the Reopsitory project AddEmployee method
            _employeeService.Add(empl); 

            return CreatedAtRoute("DefaultApi", new { id = empl.EmpId }, empl);
        }

        //// DELETE: api/Books//5
        // we can perform delete employee method
        [ResponseType(typeof(EmployeeDto))]
        public IHttpActionResult DeleteEmployee(int id)
        {
            EmployeeDto empl = _employeeService.Get(id);
            if (empl == null)
            {
                return NotFound();
            }
            // Calling the Reopsitory project RemoveEmployee method
            _employeeService.Remove(id);  

            return Ok(empl);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
               // _employeeService.Dispose();
            }
            base.Dispose(disposing);
        }


    }
}
