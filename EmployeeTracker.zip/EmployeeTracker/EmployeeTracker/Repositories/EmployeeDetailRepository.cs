﻿using Microsoft.Practices.Unity;
using EmployeeTracker.Repositories;
using EmployeeTracker.Models;
using System.Collections.Generic;
using System.Linq;
using Unity.Attributes;

namespace EmployeeTracker.Repositories
{
    //The EmployeeInfo Repository Class. This is used to 
    //Isolate the EntitiFtamework based Data Access Layer from
    //the MVC Controller class
    public class EmployeeDetailRepository : IRepository<EmployeeDetail, int>
    {
        [Dependency]
        public EmployeeTrackerEntities context { get; set; }

		//  employee List with qualification + training attended
     public IEnumerable<EmployeeDetail> Get()
     {
       var employeewithdetails = (
                              from emp in context.Employees
                              join empDetails in context.EmployeeDetails
                              on emp.EmpId equals empDetails.EmpId
                              select new EmployeeDetail
                              {
                               EmpId = emp.EmpId,
                               Qualification = empDetails.Qualification,
                               Training = empDetails.Training
                              }).ToList();

        return employeewithdetails;
     }

     // Find  details along with employee name using id
     public EmployeeDetail Get(int Emp_Id)
     {
        var employeewithdetails = (
                              from emp in context.Employees
                              join empDetails in context.EmployeeDetails
                              on emp.EmpId equals empDetails.EmpId
                              where emp.EmpId == Emp_Id
                              select new EmployeeDetail
                              {
                               EmpId = emp.EmpId,
                               Qualification = empDetails.Qualification,
                               Training = empDetails.Training
                              }).FirstOrDefault();


         return employeewithdetails;
      }

        //public IEnumerable<EmployeeDetail> Get()
        //{
           // return context.EmployeeDetails.ToList();
        //}

       // public EmployeeDetail Get(int id)
        //{
            //return context.EmployeeDetails.Find(id);
        //}

        public void Add(EmployeeDetail entity)
        {
            context.EmployeeDetails.Add(entity);
            context.SaveChanges();
        }
		 // Edit a Employee
      public void Edit(EmployeeDetail entity)
      {
         context.Entry(entity).State = System.Data.Entity.EntityState.Modified;
         context.SaveChanges();
      }

        public void Remove(EmployeeDetail entity)
        {
            var obj = context.EmployeeDetails.Find(entity.EmpId);
            context.EmployeeDetails.Remove(obj);
            context.SaveChanges();
        }
    }
}