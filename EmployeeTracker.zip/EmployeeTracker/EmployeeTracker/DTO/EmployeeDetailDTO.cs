using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EmployeeTracker.Models;

namespace EmployeeTracker.DTO
{
    public class EmployeeDto
    {
        //public Employee empObj {get;set;} 
        //public EmployeeDetail empDetailObj { get; set; }
        //public Manager managerObj { get; set; }
		 [Dependency]
        private EmployeeTrackerEntities context { get; set; }
        public string Qualification { get; set; }
        public string Training { get; set; }
        public string ManagerName { get; set; }
        public string ManagerAddress { get; set; }
        public Nullable<int> ManagerContact { get; set; }
        public string ManagerDepartment { get; set; }
		 }
}